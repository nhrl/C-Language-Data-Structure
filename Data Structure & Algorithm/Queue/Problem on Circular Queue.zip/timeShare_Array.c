#include <stdio.h>
#include <windows.h>
#include <string.h>
#include <stdbool.h>

#define F while (getchar() != '\n')
#define S 10
#define Q 4
#define T 10

typedef struct
{
	char proc_Name[S];
	int duration;
}PROCESS;

typedef struct
{
	PROCESS queue[Q];
	int q_Front;
	int q_Rear;
}QUEUE;

QUEUE createCQueue(void);
void enCQueue(QUEUE *, PROCESS);
PROCESS deCQueue(QUEUE *);
bool isCEmpty(int, int);
bool isCFull(int, int);

PROCESS input_Process(void);
void time_Share_Simulation(void);

int main(void)
{
	time_Share_Simulation();
	return;
}

QUEUE createCQueue(void)
{
	QUEUE que;
	que.q_Front = 0;
	que.q_Rear = 0;
	return que;
}

void enCQueue(QUEUE *que, PROCESS process)
{
	que->queue[que->q_Rear] = process;
	que->q_Rear = (que->q_Rear + 1) % Q;
	return;
}

PROCESS deCQueue(QUEUE *que)
{
	PROCESS process = que->queue[que->q_Front];
	que->q_Front = (que->q_Front + 1) % Q;
	return process;
}

bool isCEmpty(int front, int rear)
{
	bool empty = false;
	if(front == rear)
		empty = true;
	return empty;
}

bool isCFull(int front, int rear)
{
	bool full = false;
	if (front == (rear + 1) % Q)
		full = true;
	return full;
}

PROCESS input_Process(void)
{
	PROCESS process;
	F;
	printf("\n\n\tProcess Name: ");
	gets(process.proc_Name);
	printf("\n\tProcess Duration: ");
	scanf("%d",&process.duration);
	return process;
}
void time_Share_Simulation(void)
{
	bool empty, full;
	PROCESS process;
	QUEUE que;
	
	que = createCQueue();
	
	full = isCFull(que.q_Front,que.q_Rear);
	while(!full) // for the input of 5 processes
	{
		process = input_Process();
		enCQueue(&que, process);
		full = isCFull(que.q_Front,que.q_Rear);
	}
	empty = isCEmpty(que.q_Front, que.q_Rear);
	while(!empty)
	{
		process = deCQueue(&que);
		printf("\n\n\tProcessing application: %s",process.proc_Name);
		printf("\n\tDuration: %d",process.duration);
		if (process.duration > T)
		{
			process.duration = process.duration - T;
			sleep(T);
			full = isCFull(que.q_Front,que.q_Rear);
			if (full)
			{
				printf("\n\n\tError: cannot continue, queue is full...");
				sleep(2);
				return;
			}
			else
				enCQueue(&que, process);
			printf("\n\tRemaining Time: %d",process.duration);
		}
		else
		{
			sleep(process.duration);
			printf("\n\tProcess %s is complete...",process.proc_Name);
		}
		empty = isCEmpty(que.q_Front, que.q_Rear);
	}// end of while(!empty)
	printf("\n\n\tAll jobs are executed...");
	sleep(3);
	return;
}
